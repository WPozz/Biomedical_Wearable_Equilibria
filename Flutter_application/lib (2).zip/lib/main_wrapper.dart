import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_application/providers/settings_provider.dart'; 

import 'screens/home.dart';
import 'screens/esercizi.dart';
import 'screens/profile.dart';
import 'screens/analysis_and_trends.dart';

class MainWrapper extends StatefulWidget {
  const MainWrapper({super.key});

  @override
  State<MainWrapper> createState() => _MainWrapperState();
}

class _MainWrapperState extends State<MainWrapper> {
  int _selectedIndex = 0;

  final List<Widget> _pages = [
    const HomeScreen(),
    const AnalysisAndTrendsScreen(),
    const EserciziScreen(),
    const Profile(),
  ];

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    
    // Ascolta i cambiamenti di lingua dal provider
    final isItalian = context.watch<SettingsProvider>().isItalian; 

    return Scaffold(
      body: IndexedStack(
        index: _selectedIndex,
        children: _pages,
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _selectedIndex,
        onDestinationSelected: (int index) {
          setState(() {
            _selectedIndex = index;
          });
        },
        backgroundColor: colorScheme.surface,
        indicatorColor: colorScheme.secondaryContainer,
        destinations: [ 
          NavigationDestination(
            icon: const Icon(Icons.grid_view_rounded),
            label: isItalian ? 'Home' : 'Home', 
          ),
          NavigationDestination(
            icon: const Icon(Icons.analytics_rounded),
            label: isItalian ? 'Dati' : 'Data',
          ),
          NavigationDestination(
            icon: const Icon(Icons.play_circle_filled_rounded),
            label: isItalian ? 'Esercizi' : 'Exercises',
          ),
          NavigationDestination(
            icon: const Icon(Icons.person_rounded),
            label: isItalian ? 'Profilo' : 'Profile',
          ),
        ],
      ),
    );
  }
}