// lib/screens/report_archivio.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_application/providers/settings_provider.dart';
import 'package:flutter_application/providers/data_provider.dart';
import 'package:flutter_application/utils/weekly_report_model.dart';
import 'package:flutter_application/services/weekly_report_builder.dart';
import 'report_dettaglio.dart';

class ReportArchivioScreen extends StatefulWidget {
  const ReportArchivioScreen({super.key});

  @override
  State<ReportArchivioScreen> createState() => _ReportArchivioScreenState();
}

class _ReportArchivioScreenState extends State<ReportArchivioScreen> {
  // null = non ancora caricato; lista vuota = caricamento in corso
  List<WeeklyReport>? _reports;
  bool _isLoading = true;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    // Usiamo addPostFrameCallback per leggere il Provider in sicurezza
    WidgetsBinding.instance.addPostFrameCallback((_) => _loadReports());
  }

  Future<void> _loadReports() async {
    if (!mounted) return;
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      final dataProvider   = context.read<DataProvider>();
      final settings       = context.read<SettingsProvider>();
      final stepsTarget    = settings.steps;
      final sleepTarget    = settings.sleepHours.toDouble(); // int → double
      final goalsEnabled   = settings.customGoalsEnabled;

      // 8 settimane caricate in gruppi da 2 (chunk).
      // - Seriale puro (chunk=1): nessun ECONNABORTED ma lentissimo
      // - Parallelo puro (chunk=8): veloce ma crasha il server
      // - chunk=2: compromesso — 4 gruppi, 300ms di pausa tra i gruppi,
      //   la UI aggiorna progressivamente dopo ogni gruppo.
      // Se torna ECONNABORTED abbassa chunkSize a 1.
      const int chunkSize = 2;
      final ranges = WeeklyReportBuilder.buildWeekRanges();

      // Pre-popola con placeholder vuoti così la lista ha subito la lunghezza giusta
      final List<WeeklyReport> reports = ranges.map((r) => WeeklyReport.empty(
        weekStart:   r.start,
        weekEnd:     r.end,
        dateRangeIt: '',
        dateRangeEn: '',
      )).toList();
      if (mounted) setState(() => _reports = List.from(reports));

      for (int i = 0; i < ranges.length; i += chunkSize) {
        if (!mounted) return;

        final int end = (i + chunkSize).clamp(0, ranges.length);
        final chunk   = ranges.sublist(i, end);

        final chunkReports = await Future.wait(
          chunk.map((r) => WeeklyReportBuilder.build(
            dataProvider:    dataProvider,
            weekStart:       r.start,
            weekEnd:         r.end,
            stepsGoalTarget: stepsTarget,
            sleepGoalHours:  sleepTarget,
            goalsEnabled:    goalsEnabled,
          )),
        );

        for (int j = 0; j < chunkReports.length; j++) {
          reports[i + j] = chunkReports[j];
        }

        if (mounted) setState(() => _reports = List.from(reports));

        // Pausa tra i gruppi per non sovraccaricare il server
        if (end < ranges.length) {
          await Future.delayed(const Duration(milliseconds: 300));
        }
      }

      if (!mounted) return;
      setState(() => _isLoading = false);
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _isLoading    = false;
        _errorMessage = e.toString();
      });
    }
  }

  // ── Colori card per performance ────────────────────────────────────────────

  Color _bgColor(WeeklyReport r, BuildContext context) {
    if (!r.hasData) {
      return Theme.of(context).colorScheme.surfaceContainerLow;
    }
    final isDark = Theme.of(context).brightness == Brightness.dark;
    switch (r.performance) {
      case WeekPerformance.excellent:
        return isDark ? const Color(0xFF1A4D2E) : const Color(0xFFE6F4EA);
      case WeekPerformance.good:
        return isDark ? const Color(0xFF4D3A00) : const Color(0xFFFEF7E0);
      case WeekPerformance.fair:
      case WeekPerformance.poor:
        return isDark ? const Color(0xFF4D1515) : const Color(0xFFFCE8E6);
    }
  }

  Color _fgColor(WeeklyReport r, BuildContext context) {
    if (!r.hasData) {
      return Theme.of(context).colorScheme.onSurfaceVariant;
    }
    final isDark = Theme.of(context).brightness == Brightness.dark;
    switch (r.performance) {
      case WeekPerformance.excellent:
        return isDark ? const Color(0xFF6EE7A0) : const Color(0xFF137333);
      case WeekPerformance.good:
        return isDark ? const Color(0xFFFDE68A) : const Color(0xFFB06000);
      case WeekPerformance.fair:
      case WeekPerformance.poor:
        return isDark ? const Color(0xFFF87171) : const Color(0xFFC5221F);
    }
  }

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    final isItalian   = context.watch<SettingsProvider>().isItalian;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          isItalian ? 'Calendario Report' : 'Weekly Reports',
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        actions: [
          // Bottone di reload manuale
          if (!_isLoading)
            IconButton(
              icon: Icon(Icons.refresh_rounded, color: colorScheme.primary),
              onPressed: _loadReports,
              tooltip: isItalian ? 'Ricarica' : 'Refresh',
            ),
        ],
      ),
      body: SafeArea(
        child: _buildBody(context, isItalian, colorScheme),
      ),
    );
  }

  Widget _buildBody(
    BuildContext context,
    bool isItalian,
    ColorScheme colorScheme,
  ) {
    // Stato: caricamento
    if (_isLoading) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const CircularProgressIndicator(),
            const SizedBox(height: 16),
            Text(
              isItalian
                  ? 'Caricamento report in corso…'
                  : 'Loading reports…',
              style: TextStyle(color: colorScheme.onSurfaceVariant),
            ),
          ],
        ),
      );
    }

    // Stato: errore
    if (_errorMessage != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.wifi_off_rounded,
                  size: 48, color: colorScheme.error),
              const SizedBox(height: 16),
              Text(
                isItalian
                    ? 'Impossibile caricare i report.\nControlla la connessione.'
                    : 'Could not load reports.\nCheck your connection.',
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 16),
              ),
              const SizedBox(height: 24),
              FilledButton.icon(
                onPressed: _loadReports,
                icon: const Icon(Icons.refresh),
                label: Text(isItalian ? 'Riprova' : 'Retry'),
              ),
            ],
          ),
        ),
      );
    }

    // Stato: dati pronti
    final reports = _reports ?? [];

    return ListView.builder(
      padding: const EdgeInsets.all(20),
      itemCount: reports.length,
      itemBuilder: (context, index) {
        final report  = reports[index];
        final bgCol   = _bgColor(report, context);
        final fgCol   = _fgColor(report, context);

        return _ReportCard(
          report:    report,
          bgColor:   bgCol,
          fgColor:   fgCol,
          isItalian: isItalian,
          onTap: report.hasData
              ? () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => ReportDettaglioScreen(report: report),
                    ),
                  )
              : null, // card non tappabile se senza dati
        );
      },
    );
  }
}

// ── Card singola ─────────────────────────────────────────────────────────────

class _ReportCard extends StatelessWidget {
  final WeeklyReport report;
  final Color bgColor;
  final Color fgColor;
  final bool isItalian;
  final VoidCallback? onTap;

  const _ReportCard({
    required this.report,
    required this.bgColor,
    required this.fgColor,
    required this.isItalian,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;

    final String subtitle = !report.hasData
        ? (isItalian ? 'Nessun dato disponibile per questa settimana' : 'No data available for this week')
        : report.goalsEnabled
            ? (isItalian
                ? 'Andamento settimana: ${report.evaluationIt}'
                : 'Week performance: ${report.evaluationEn}')
            : (isItalian
                ? 'Andamento settimana: ${report.evaluationIt} · Obiettivi non attivi'
                : 'Week performance: ${report.evaluationEn} · No active goals');

    return Card(
      margin: const EdgeInsets.only(bottom: 14),
      elevation: 0,
      color: bgColor,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(color: fgColor.withOpacity(0.15)),
      ),
      child: ListTile(
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        leading: CircleAvatar(
          backgroundColor: fgColor.withOpacity(0.15),
          child: Icon(
            report.hasData
                ? Icons.analytics_rounded
                : Icons.hourglass_empty_rounded,
            color: fgColor,
          ),
        ),
        title: Text(
          isItalian ? report.dateRangeIt : report.dateRangeEn,
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: fgColor,
            fontSize: 16,
          ),
        ),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 4),
          child: Text(
            subtitle,
            style: TextStyle(
              fontSize: 13,
              color: fgColor.withOpacity(0.85),
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
        trailing: report.hasData
            ? Icon(Icons.arrow_forward_ios_rounded, size: 14, color: fgColor)
            : null,
        onTap: onTap,
      ),
    );
  }
}