// lib/services/weekly_report_builder.dart
//
// Costruisce un WeeklyReport reale partendo dai dati API.
// Dipende da DataProvider (fetch) e StressCalculator (formula stress).
// Tutti i metodi sono statici: niente stato, niente ChangeNotifier.

import 'dart:math' as math;
import 'package:flutter_application/providers/data_provider.dart';
import 'package:flutter_application/utils/weekly_report_model.dart';
import 'package:flutter_application/models/metric_point.dart';
import 'package:flutter_application/services/stress_calculator.dart';

abstract class WeeklyReportBuilder {

  /// Data massima accettata dall'API (end_date deve essere strettamente < oggi).
  /// Usata come ancora in analysis_and_trends.dart e in buildWeekRanges().
  static final DateTime kArchiveEnd = DateTime(2026, 6, 21);

  // ──────────────────────────────────────────────────────────────────────────
  // ENTRY POINT PRINCIPALE
  // ──────────────────────────────────────────────────────────────────────────

  /// Costruisce il report per [weekStart] – [weekEnd].
  /// Se non ci sono dati ritorna un WeeklyReport con hasData = false.
  static Future<WeeklyReport> build({
    required DataProvider dataProvider,
    required DateTime weekStart,
    required DateTime weekEnd,
    required int stepsGoalTarget,
    required double sleepGoalHours,
    required bool goalsEnabled,
  }) async {
    final String startStr = _fmt(weekStart);
    final String endStr   = _fmt(weekEnd);

    // Settimana precedente per i delta
    final DateTime prevStart = weekStart.subtract(const Duration(days: 7));
    final DateTime prevEnd   = weekEnd.subtract(const Duration(days: 7));

    // Fetch ottimizzati: fetchWeekBundle scarica sleep+steps+hr una volta sola.
    // Lo stress viene calcolato qui con StressCalculator invece di chiamare
    // fetchCalculatedStressRange (che rifarebbe le stesse 3 fetch).
    // Risultato: 3 chiamate HTTP per la settimana corrente + 2 per la precedente
    // (hr non serve per i delta), invece delle 7 di prima.

    // Settimana corrente
    final bundle = await dataProvider.fetchWeekBundle(startStr, endStr);
    final sleepPoints = bundle.sleep;
    final stepsPoints = bundle.steps;
    final hrPoints    = bundle.hr;

    // Stress calcolato localmente dai dati già in mano
    final stressPoints = _computeStressPoints(sleepPoints, stepsPoints, hrPoints, weekStart);
    await Future.delayed(const Duration(milliseconds: 200));

    // Settimana precedente — solo sleep e steps (hr non serve per i delta)
    final prevSleep  = await dataProvider.fetchMetricRange('sleep', _fmt(prevStart), _fmt(prevEnd));
    await Future.delayed(const Duration(milliseconds: 150));
    final prevSteps  = await dataProvider.fetchMetricRange('steps', _fmt(prevStart), _fmt(prevEnd));
    await Future.delayed(const Duration(milliseconds: 150));
    final prevStress = _computeStressPoints(prevSleep, prevSteps, [], prevStart);

    // DailyStress allineati ai 7 giorni della settimana
    final List<DailyStress> dailyStress = _buildDailyStress(
      weekStart: weekStart,
      stressPoints: stressPoints,
    );

    // Aggregati correnti
    final double avgStress = _avg(stressPoints.map((p) => p.value).toList());
    final double avgSleep  = _avg(sleepPoints.map((p) => p.value).toList());
    final double avgSteps  = _avg(stepsPoints.map((p) => p.value).toList());

    // Aggregati settimana precedente
    final double prevAvgStress = _avg(prevStress.map((p) => p.value).toList());
    final double prevAvgSleep  = _avg(prevSleep.map((p) => p.value).toList());
    final double prevAvgSteps  = _avg(prevSteps.map((p) => p.value).toList());

    // Giorno più stressante
    final String mostStressfulDay = dailyStress.isNotEmpty
        ? _dayName(dailyStress
            .reduce((a, b) => a.stressIndex > b.stressIndex ? a : b)
            .date)
        : 'N/A';

    // Peak HR time range (proxy del picco di stress)
    final String peakTimeRange  = hrPoints.isNotEmpty ? _peakHrRange(hrPoints) : 'N/A';
    final int    peakDaysCount  = hrPoints.isNotEmpty ? _peakDays(hrPoints)    : 0;

    // Correlazioni Pearson sleep↔stress e steps↔stress
    // Segno invertito: positivo = beneficio (più sonno/passi → meno stress)
    final double sleepCorr = _pearson(
      _alignByDate(sleepPoints,  stressPoints, weekStart),
    );
    final double stepsCorr = _pearson(
      _alignByDate(stepsPoints, stressPoints, weekStart),
    );

    // Obiettivi raggiunti
    final int stepsGoalDays = goalsEnabled
        ? stepsPoints.where((p) => p.value >= stepsGoalTarget).length
        : 0;
    final int sleepGoalDays = goalsEnabled
        ? sleepPoints.where((p) => p.value >= sleepGoalHours).length
        : 0;

    // Labels
    final String dateRangeIt = _dateRangeIt(weekStart, weekEnd);
    final String dateRangeEn = _dateRangeEn(weekStart, weekEnd);

    // Prima istanza per ricavare performance.label
    final WeeklyReport draft = WeeklyReport(
      weekStart: weekStart,
      weekEnd: weekEnd,
      hasData: dailyStress.isNotEmpty,
      evaluationIt: '',
      evaluationEn: '',
      dateRangeIt: dateRangeIt,
      dateRangeEn: dateRangeEn,
      goalsAchieved: stepsGoalDays + sleepGoalDays,
      avgStressIndex: avgStress,
      dailyStress: dailyStress,
      mostStressfulDay: mostStressfulDay,
      peakStressTimeRange: peakTimeRange,
      peakStressDaysCount: peakDaysCount,
      avgSleepHours: avgSleep,
      prevAvgSleepHours: prevAvgSleep,
      sleepStressCorrelation: sleepCorr,
      avgDailySteps: avgSteps,
      prevAvgDailySteps: prevAvgSteps,
      exerciseSessions: 0,
      stepsStressCorrelation: stepsCorr,
      prevAvgStressIndex: prevAvgStress,
      goalsEnabled: goalsEnabled,
      stepsGoalDaysReached: stepsGoalDays,
      sleepGoalDaysReached: sleepGoalDays,
      stepsGoalTarget: stepsGoalTarget,
      sleepGoalHours: sleepGoalHours,
    );

    return WeeklyReport(
      weekStart: weekStart,
      weekEnd: weekEnd,
      hasData: dailyStress.isNotEmpty,
      evaluationIt: draft.performance.label(true),
      evaluationEn: draft.performance.label(false),
      dateRangeIt: dateRangeIt,
      dateRangeEn: dateRangeEn,
      goalsAchieved: stepsGoalDays + sleepGoalDays,
      avgStressIndex: avgStress,
      dailyStress: dailyStress,
      mostStressfulDay: mostStressfulDay,
      peakStressTimeRange: peakTimeRange,
      peakStressDaysCount: peakDaysCount,
      avgSleepHours: avgSleep,
      prevAvgSleepHours: prevAvgSleep,
      sleepStressCorrelation: sleepCorr,
      avgDailySteps: avgSteps,
      prevAvgDailySteps: prevAvgSteps,
      exerciseSessions: 0,
      stepsStressCorrelation: stepsCorr,
      prevAvgStressIndex: prevAvgStress,
      goalsEnabled: goalsEnabled,
      stepsGoalDaysReached: stepsGoalDays,
      sleepGoalDaysReached: sleepGoalDays,
      stepsGoalTarget: stepsGoalTarget,
      sleepGoalHours: sleepGoalHours,
    );
  }

  // ──────────────────────────────────────────────────────────────────────────
  // RANGE ARCHIVIO (8 settimane fino al 26-06-2026)
  // ──────────────────────────────────────────────────────────────────────────

  static List<({DateTime start, DateTime end})> buildWeekRanges({
    DateTime? archiveEnd,
    int weekCount = 8,
  }) {
    final DateTime end = archiveEnd ?? kArchiveEnd;
    final List<({DateTime start, DateTime end})> ranges = [];
    DateTime weekEnd = end;

    for (int i = 0; i < weekCount; i++) {
      final DateTime weekStart = weekEnd.subtract(const Duration(days: 6));
      ranges.add((start: weekStart, end: weekEnd));
      weekEnd = weekStart.subtract(const Duration(days: 1));
    }
    return ranges; // dalla più recente alla più vecchia
  }

  // ──────────────────────────────────────────────────────────────────────────
  // DAILY STRESS
  // ──────────────────────────────────────────────────────────────────────────

  // ──────────────────────────────────────────────────────────────────────────
  // CALCOLO STRESS LOCALE (nessuna fetch HTTP)
  // ──────────────────────────────────────────────────────────────────────────

  /// Calcola i MetricPoint dello stress a partire dai raw data già scaricati.
  /// Evita di richiamare fetchCalculatedStressRange che rifarebbe sleep+steps+hr.
  static List<MetricPoint> _computeStressPoints(
    List<MetricPoint> sleepPoints,
    List<MetricPoint> stepsPoints,
    List<MetricPoint> hrPoints,
    DateTime weekStart,
  ) {
    // Mappa per data → valori raw
    final Map<String, DailyRawData> rawMap = {};

    void populate(List<MetricPoint> points, void Function(DailyRawData, double) assign) {
      for (final p in points) {
        rawMap.putIfAbsent(p.fullLabel, () => DailyRawData(shortLabel: p.shortLabel));
        assign(rawMap[p.fullLabel]!, p.value);
      }
    }

    populate(sleepPoints, (d, v) => d.sleepHours = v);
    populate(stepsPoints, (d, v) => d.steps = v);
    populate(hrPoints,    (d, v) => d.heartRate = v);

    return rawMap.entries
    .where((e) =>
        e.value.sleepHours > 0 ||
        e.value.heartRate > 0 ||
        e.value.steps > 0)  // ← salta i giorni completamente vuoti
    .map((e) => MetricPoint(
          shortLabel: e.value.shortLabel,
          fullLabel:  e.key,
          value:      StressCalculator.calculateDailyStress(e.value),
        ))
    .toList()
  ..sort((a, b) => a.fullLabel.compareTo(b.fullLabel));
  }

  static List<DailyStress> _buildDailyStress({
    required DateTime weekStart,
    required List<MetricPoint> stressPoints,
  }) {
    final Map<String, double> byDate = {
      for (final p in stressPoints) p.fullLabel: p.value,
    };

    final List<DailyStress> result = [];
    for (int i = 0; i < 7; i++) {
      final DateTime day = weekStart.add(Duration(days: i));
      final String key = _fmt(day);
      if (byDate.containsKey(key)) {
        result.add(DailyStress(date: day, stressIndex: byDate[key]!));
      }
    }
    return result;
  }

  // ──────────────────────────────────────────────────────────────────────────
  // CORRELAZIONE DI PEARSON
  // ──────────────────────────────────────────────────────────────────────────

  /// Allinea X (sleep/steps) e Y (stress) per data, ritorna coppie (x, y).
  static List<(double x, double y)> _alignByDate(
    List<MetricPoint> xPoints,
    List<MetricPoint> yPoints,
    DateTime weekStart,
  ) {
    final Map<String, double> xMap = {for (final p in xPoints) p.fullLabel: p.value};
    final Map<String, double> yMap = {for (final p in yPoints) p.fullLabel: p.value};

    final List<(double, double)> pairs = [];
    for (int i = 0; i < 7; i++) {
      final String key = _fmt(weekStart.add(Duration(days: i)));
      if (xMap.containsKey(key) && yMap.containsKey(key)) {
        final double x = xMap[key]!;
        final double y = yMap[key]!;
        if (x > 0 && y > 0) pairs.add((x, y));
      }
    }
    return pairs;
  }

  /// Pearson r su coppie (x, y), scalato a [-100, +100].
  /// Il segno è invertito: positivo = "più X → meno stress" (beneficio).
  static double _pearson(List<(double x, double y)> pairs) {
    if (pairs.length < 3) return 0.0;

    final double meanX = pairs.map((p) => p.$1).reduce((a, b) => a + b) / pairs.length;
    final double meanY = pairs.map((p) => p.$2).reduce((a, b) => a + b) / pairs.length;

    double num = 0, denomX = 0, denomY = 0;
    for (final p in pairs) {
      final double dx = p.$1 - meanX;
      final double dy = p.$2 - meanY;
      num    += dx * dy;
      denomX += dx * dx;
      denomY += dy * dy;
    }

    final double denom = math.sqrt(denomX) * math.sqrt(denomY);
    if (denom < 1e-9) return 0.0;

    // Invertiamo: r negativo (più X → meno stress) → valore positivo nella UI
    return (-(num / denom) * 100).clamp(-100.0, 100.0).roundToDouble();
  }

  // ──────────────────────────────────────────────────────────────────────────
  // PEAK HR TIME RANGE
  // ──────────────────────────────────────────────────────────────────────────

  /// Trova la finestra di 2 ore consecutive con HR medio più alto sull'intera settimana.
  static String _peakHrRange(List<MetricPoint> hrPoints) {
    // shortLabel = "HH:MM" → aggrega per ora
    final Map<int, List<double>> byHour = {};
    for (final p in hrPoints) {
      final parts = p.shortLabel.split(':');
      if (parts.isEmpty) continue;
      final int? hour = int.tryParse(parts[0]);
      if (hour == null) continue;
      byHour.putIfAbsent(hour, () => []).add(p.value);
    }
    if (byHour.isEmpty) return 'N/A';

    final Map<int, double> hourlyAvg = {
      for (final e in byHour.entries)
        e.key: e.value.reduce((a, b) => a + b) / e.value.length,
    };

    double bestAvg = -1;
    int bestHour = 9;
    final List<int> hours = hourlyAvg.keys.toList()..sort();

    for (int i = 0; i < hours.length - 1; i++) {
      final int h1 = hours[i];
      final int h2 = hours[i + 1];
      if (h2 - h1 == 1) {
        final double windowAvg = (hourlyAvg[h1]! + hourlyAvg[h2]!) / 2;
        if (windowAvg > bestAvg) {
          bestAvg  = windowAvg;
          bestHour = h1;
        }
      }
    }

    final String h1 = bestHour.toString().padLeft(2, '0');
    final String h2 = (bestHour + 2).toString().padLeft(2, '0');
    return '$h1:00 – $h2:00';
  }

  /// Conta i giorni lavorativi (lun–ven) in cui il picco HR cade in orario lavorativo.
  static int _peakDays(List<MetricPoint> hrPoints) {
    // Raggruppa per data → ora → valori HR
    final Map<String, Map<int, List<double>>> byDateHour = {};
    for (final p in hrPoints) {
      final String label = p.fullLabel;
      final String datePart = label.length >= 10 ? label.substring(0, 10) : label;
      final parts = p.shortLabel.split(':');
      if (parts.isEmpty) continue;
      final int? hour = int.tryParse(parts[0]);
      if (hour == null) continue;
      byDateHour.putIfAbsent(datePart, () => {});
      byDateHour[datePart]!.putIfAbsent(hour, () => []).add(p.value);
    }

    int count = 0;
    for (final entry in byDateHour.entries) {
      final DateTime? date = DateTime.tryParse(entry.key);
      if (date == null || date.weekday > 5) continue; // solo lun–ven

      final Map<int, double> hourlyAvg = {
        for (final e in entry.value.entries)
          e.key: e.value.reduce((a, b) => a + b) / e.value.length,
      };
      if (hourlyAvg.isEmpty) continue;

      final int peakHour = hourlyAvg.entries
          .reduce((a, b) => a.value > b.value ? a : b)
          .key;

      if (peakHour >= 8 && peakHour <= 19) count++;
    }
    return count.clamp(0, 5);
  }

  // ──────────────────────────────────────────────────────────────────────────
  // DATE UTILITIES
  // ──────────────────────────────────────────────────────────────────────────

  static double _avg(List<double> values) {
    final nonZero = values.where((v) => v > 0).toList();
    if (nonZero.isEmpty) return 0.0;
    return nonZero.reduce((a, b) => a + b) / nonZero.length;
  }

  static String _fmt(DateTime d) =>
      '${d.year.toString().padLeft(4, '0')}-'
      '${d.month.toString().padLeft(2, '0')}-'
      '${d.day.toString().padLeft(2, '0')}';

  static String _dayName(DateTime d) {
    const days = ['Monday', 'Tuesday', 'Wednesday',
                  'Thursday', 'Friday', 'Saturday', 'Sunday'];
    return days[d.weekday - 1];
  }

  static String _dateRangeIt(DateTime s, DateTime e) {
    const m = ['', 'Gen', 'Feb', 'Mar', 'Apr', 'Mag', 'Giu',
                'Lug', 'Ago', 'Set', 'Ott', 'Nov', 'Dic'];
    return '${s.day} ${m[s.month]} – ${e.day} ${m[e.month]} ${e.year}';
  }

  static String _dateRangeEn(DateTime s, DateTime e) {
    const m = ['', 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return '${m[s.month]} ${s.day.toString().padLeft(2, '0')} – '
           '${m[e.month]} ${e.day.toString().padLeft(2, '0')} ${e.year}';
  }
}