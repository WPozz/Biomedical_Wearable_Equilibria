// lib/services/stress_calculator.dart
//
// Logica di calcolo dello Stress Index (formula Proxy IUSM).
// Classe pura: nessuna dipendenza da Flutter, HTTP o Provider.
// Può essere riusata da qualsiasi screen o service senza importare DataProvider.

/// Dati grezzi giornalieri necessari per il calcolo dello stress.
class DailyRawData {
  String shortLabel;
  double sleepHours;
  double heartRate;
  double steps;

  DailyRawData({
    required this.shortLabel,
    this.sleepHours = 0,
    this.heartRate = 0,
    this.steps = 0,
  });
}

/// Calcola lo Stress Index su base giornaliera usando la formula Proxy IUSM.
///
/// La formula combina tre fattori:
/// - Penalità sonno: ogni ora sotto le 8h aggiunge stress
/// - Carico simpatico: HR medio sopra 65 bpm aggiunge stress
/// - Gating contestuale: i passi alti riducono il peso dell'HR elevato
///
/// Ritorna un valore nell'intervallo [0.0, 100.0].
abstract class StressCalculator {
  // --- Costanti di calibrazione (cambiale qui senza toccare il resto) ---
  static const double _baseStress = 20.0;
  static const double _idealSleepHours = 8.0;
  static const double _sleepPenaltyPerHour = 10.0;
  static const double _missingDataSleepPenalty = 30.0;
  static const double _restingHrThreshold = 65.0;
  static const double _hrPenaltyFactor = 0.8;
  static const double _activityReliefPer1000Steps = 2.0;

  /// Calcola lo stress per un singolo [DailyRawData].
  static double calculateDailyStress(DailyRawData raw) {
    // Nessun dato disponibile → valore neutro
    if (raw.sleepHours == 0 && raw.heartRate == 0 && raw.steps == 0) {
      return 0.0;
    }

    // 1. Penalità Sonno
    double sleepPenalty;
    if (raw.sleepHours > 0) {
      sleepPenalty = (_idealSleepHours - raw.sleepHours) * _sleepPenaltyPerHour;
      if (sleepPenalty < 0) sleepPenalty = 0; // Nessun bonus per troppo sonno
    } else {
      sleepPenalty = _missingDataSleepPenalty;
    }

    // 2. Carico Simpatico (HR medio alto)
    double hrPenalty = 0.0;
    if (raw.heartRate > _restingHrThreshold) {
      hrPenalty = (raw.heartRate - _restingHrThreshold) * _hrPenaltyFactor;
    }

    // 3. Gating Contestuale (i passi riducono il peso dell'HR alto)
    final double activityRelief =
        (raw.steps / 1000.0) * _activityReliefPer1000Steps;

    final double finalStress =
        _baseStress + sleepPenalty + hrPenalty - activityRelief;

    return finalStress.clamp(0.0, 100.0).roundToDouble();
  }

  /// Calcola lo stress per una lista di [DailyRawData] e ritorna
  /// una Map<fullLabel, stressValue> pronta per la costruzione dei MetricPoint.
  static Map<String, double> calculateStressForDays(
      List<DailyRawData> rawDataList) {
    return {
      for (final raw in rawDataList)
        raw.shortLabel: calculateDailyStress(raw),
    };
  }
}